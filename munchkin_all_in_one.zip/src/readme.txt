 
Unzip data.zip in data folder
Unzip SDL2_ttf.zip in src folder

Windows
-------
Run the munchkin.exe (is an 32 bits executable)

Linux
------
$ export LD_LIBRARY_PATH=<folder where munchkin/src/linux_libs is located>
$ cd src  
$ chmod 644 munchkin
$ ./munchkin           (is an 64 bits executable)
